EDF Tempo Stream Deck — Pack Tout-en-un (v1.2.7)
- Ajout: touche HIER (même format)
- Ajout: Stats BLEU/BLANC/ROUGE (RESTE + PASSÉ)
Utilisation: lancer INSTALL_SILENT.bat puis importer le plugin si demandé.
