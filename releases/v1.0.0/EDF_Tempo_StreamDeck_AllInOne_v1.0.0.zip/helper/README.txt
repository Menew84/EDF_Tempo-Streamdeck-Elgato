EDF Tempo Local Helper v1.1.3
- /tempo now returns today/tomorrow/yesterday + stats
- /stats returns only stats
