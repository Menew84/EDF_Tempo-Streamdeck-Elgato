$ErrorActionPreference = "Stop"
$ProgramData = [Environment]::GetFolderPath("CommonApplicationData")
$TargetDir = Join-Path $ProgramData "EDFTempoHelper"
$SourceDir = Join-Path $PSScriptRoot "helper"

New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
Copy-Item -Path (Join-Path $SourceDir "*") -Destination $TargetDir -Recurse -Force

$py = (Get-Command py -ErrorAction SilentlyContinue)
if (-not $py) { throw "Python Launcher 'py' not found. Install Python 3 and ensure the 'py' launcher exists." }

$TaskName = "EDF Tempo Helper"
$BatPath = Join-Path $TargetDir "START_HELPER_HIDDEN.bat"

$Action = New-ScheduledTaskAction -Execute $BatPath
$Trigger = New-ScheduledTaskTrigger -AtLogOn
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew

try { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue | Out-Null } catch {}
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Description "Runs EDF Tempo helper (localhost:9123) for Stream Deck plugin" | Out-Null

Start-Process -FilePath $BatPath -WindowStyle Hidden

$PluginFile = Join-Path $PSScriptRoot "EDF_Tempo_Local_Helper_Plugin_v2_1.2.7.streamDeckPlugin"
if (Test-Path $PluginFile) { Start-Process -FilePath $PluginFile | Out-Null }
